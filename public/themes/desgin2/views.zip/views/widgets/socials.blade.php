<div class="widget_wrapper">
    <div class="widget_header">
        <h3>اتبعنا على فيسبوك</h3>
    </div>

    <div class="fb-page" data-href="https://www.facebook.com/{!! Settings::get('facebook') !!}/" data-tabs="timeline" data-width="300" data-height="300" data-small-header="false" data-adapt-container-width="true" data-hide-cover="false" data-show-facepile="true"><blockquote cite="https://www.facebook.com/alyoum8th/" class="fb-xfbml-parse-ignore"><a href="https://www.facebook.com/{!! Settings::get('facebook') !!}/">‎{!! Settings::get('websiteName') !!}</a></blockquote></div>


    <div class="widget_header">
        <h3>اتبعنا على تويتر</h3>
    </div>

    <a class="twitter-timeline" data-lang="ar" data-height="300" href="https://twitter.com/{!! Settings::get('twitter') !!}">Tweets by {!! Settings::get('websiteName') !!}</a> <script async src="//platform.twitter.com/widgets.js" charset="utf-8"></script>

</div>
