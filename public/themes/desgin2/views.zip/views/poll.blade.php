{{ PollWriter::draw(1, new Systems\Voting ) }}
