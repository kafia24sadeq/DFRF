@extends("layouts.master")
@section('title' , $photos[0]->imageCategory->name )
@section('pageheading',  $photos[0]->imageCategory->name )



{!! MetaTags($photos[0]->imageCategory->name, "",  "" ) !!}

@section("content")
    <div class="page-header">
        <h1>{!! $photos[0]->imageCategory->name !!}</h1>
    </div>

    <div class="">
        {{ $photos->links('vendor.pagination.bootstrap-4') }}
    </div>

    @foreach($photos as $key => $value)
        @if($photos[0]->imageCategory->id == 13)
            <div class="col-xs-6 col-sm-3" style="min-height: 400px" >
                <div class="">
                    <a href="{!! route("photo", $value->id) !!}">{{ Html::image(PhotosDir($value->name) ,  $value->name  , array('width'=>'100%','height'=>'350', 'class' => '')) }}</a>
                </div>
            </div>
        @elseif($photos[0]->imageCategory->id == 21)
            <div class="row divide-sm" >
                @if(isset($value->link))
                <div class="col-xs-12 col-sm-12 col-md-3">
                    <a href="{!! $value->link !!}">
                        <div class="resizedrow spec center-block">
                            {!!   Html::image(PhotosDir($value->name, true, [200,80]) ,  $value->image_tags  , array('width'=>'200','height'=>'80', 'class' => 'img-responsive full_width_image')) !!}
                        </div>
                    </a>
                </div>
                <div class="col-xs-12 col-sm-12 col-md-9">
                    <h3 class="title_link"><a href="{!! $value->link !!}">{!! $value->image_tags !!}</a></h3>
                    <p class="">{!!  \Illuminate\Support\Str::words(strip_tags($value->content),50, '...'); !!}</p>
                </div>
                @else
                <div class="col-xs-12 col-sm-12 col-md-3">
                    <a href="{!! route('story',$value->id) !!}">
                        <div class="resizedrow spec center-block">
                            {!!   Html::image(PhotosDir($value->name, true, [200,80]) ,  $value->image_tags  , array('width'=>'200','height'=>'80', 'class' => 'img-responsive full_width_image')) !!}
                        </div>
                    </a>
                </div>
                <div class="col-xs-12 col-sm-12 col-md-9">
                    <h3 class="title_link"><a href="{!! route('story',$value->id) !!}">{!! $value->image_tags !!}</a></h3>
                    <p class="">{!!  \Illuminate\Support\Str::words(strip_tags($value->content),50, '...'); !!}</p>
                </div>
                @endif
            </div>
        @else
            <div class="col-xs-6 col-md-6" style="min-height: 300px" >
                <div class="thumbnail">
                    <a href="{!! route("photo", $value->id) !!}">{{ Html::image(PhotosDir($value->name, true, [700,300]) ,  $value->name  , array('width'=>'700','height'=>'300', 'class' => '')) }}</a>
                </div>
            </div>
        @endif
    @endforeach

    <div class="">
        {{ $photos->links('vendor.pagination.bootstrap-4') }}
    </div>

@stop










