@extends('layouts.master')
{{--@section('breadcrumbs', Breadcrumbs::render('video', $video ))--}}
@section('title' , $video->image_tags)
@section('pageheading',  $video->imageCategory->name)



{!! MetaTags($video->image_tags, excerptHelper($video->image_tags ,150,''),  "https://www.youtube.com/embed/" ) !!}


@section('content')

    <h1 class="mainTitle">{!! $video->image_tags !!}</h1>
    <div class="panel panel-default">
        <div class="panel-body">
            <div class="video_container">
                @if($video->imageCategory->id == 13)
                    <div class="col-sm-3" style="margin-bottom: 2em">
                        {{ Html::image(PhotosDir($video->name, true, [300,400]) ,  $video->name  , array('width'=>'100%','height'=>'400px', 'class' => '')) }}
                    </div>
                    <div class="subject_font col-lg-8" style="margin: 20px 0">{!! $video->content !!}</div>
                    <div class="col-sm-3" style="clear: both">
                        <a target="_blank" class="download-btn" href="{!! $video->link !!}"><i class="fa fa-download"></i> تحميل الملف </a>
                    </div>
                @else
                    <div>
                        {{ Html::image(PhotosDir($video->name) ,  $video->name  , array('width'=>'100%','height'=>'500', 'class' => '')) }}
                    </div>
                    <div class="subject_font col-lg-8" style="margin: 20px 0">{!! $video->content !!}</div>

                @endif

            </div>
            @widget('SocialButtons')
        </div>
    </div>

    <div class="widget_header">
        <h3 style="white-space: nowrap; margin:10px 0; padding: 0;font-size: 19px;font-weight: bold;color: #59111c;" class="">{!! trans("public.more") !!}</h3>
    </div>

    @foreach($videos as $key => $value)
        @if($videos[0]->imageCategory->id ==13)
            <div class="col-xs-6 col-sm-3" style="min-height: 400px" >
                <div class="">
                    <a href="{!! route("photo", $value->id) !!}">{{ Html::image(PhotosDir($value->name) ,  $value->name  , array('width'=>'100%','height'=>'350', 'class' => '')) }}</a>

                </div>
            </div>
        @else
        <div class="col-xs-6 col-md-6" style="min-height: 300px">
            <div class="thumbnail">
                <a href="{!! route("photo", $value->id) !!}">{{ Html::image(PhotosDir($value->name, true, [700,300]) ,  $value->name  , array('width'=>'700','height'=>'300', 'class' => '')) }}</a>

            </div>
        </div>
        @endif
    @endforeach
@endsection
<style>
    .download-btn {
        /* Permalink - use to edit and share this gradient: http://colorzilla.com/gradient-editor/#f3c041+0,dda25a+19,580f1a+100 */
        background: rgb(243,192,65); /* Old browsers */
        background: -moz-linear-gradient(45deg, rgba(243,192,65,1) 0%, rgba(221,162,90,1) 19%, rgba(88,15,26,1) 100%); /* FF3.6-15 */
        background: -webkit-linear-gradient(45deg, rgba(243,192,65,1) 0%,rgba(221,162,90,1) 19%,rgba(88,15,26,1) 100%); /* Chrome10-25,Safari5.1-6 */
        background: linear-gradient(45deg, rgba(243,192,65,1) 0%,rgba(221,162,90,1) 19%,rgba(88,15,26,1) 100%); /* W3C, IE10+, FF16+, Chrome26+, Opera12+, Safari7+ */
        filter: progid:DXImageTransform.Microsoft.gradient( startColorstr='#f3c041', endColorstr='#580f1a',GradientType=1 ); /* IE6-9 fallback on horizontal gradient */        border: none;
        color: white;
        padding: 2px 13px;
        cursor: pointer;
        margin-top: 2em;
        font-size: 19px;
    }

    /* Darker background on mouse-over */
    .download-btn:hover {
        background-color: RoyalBlue;
        color: white;
        transition: all 1s ease;
    }
</style>
